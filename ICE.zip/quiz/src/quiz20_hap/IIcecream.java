package quiz20_hap;

public interface IIcecream {
	
	//사용할 메서드를 인터페이스 정의
	
	public void addIcecream(Flavor f);
	public void delIcecream();
	public int cupSize();
	public void chooseIcecream();
	
	

}
