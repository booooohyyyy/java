package quiz20_hap;

public class Flavor extends Icecream {
	
	private String flavor;
	
	
	public Flavor() {
		
	}

	public Flavor(String flavor) {
		super();
		this.flavor = flavor;
	}

	public String getFlavor() {
		return flavor;
	}

	public void setFlavor(String flavor) {
		this.flavor = flavor;
	}
	
	

	
	

}
